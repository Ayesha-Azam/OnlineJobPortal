﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OnlineJobPortal.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; //for logout
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace OnlineJobPortal.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public string adminName = "";
        public string employerName = "";
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }
        public IActionResult mainLoginPage()
        { 
            return View();
        }
        
      
       
        public IActionResult adminDashboard()
        {
            return View();
        }
        public IActionResult contactUs()
        {
            return View();
        }
        public IActionResult adminLogin()
        {


            try
            {
                var checkAdmin = JsonConvert.DeserializeObject<Class>(HttpContext.Session.GetString("AdmnSession1"));

                return View("adminDashboard");
            }
            catch (Exception)
            {
                return View();
            }

        }
        public IActionResult deleteEmployer(string emp_id)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from dbo.employer_signup where emp_email=@a", con);
            cmd.Parameters.AddWithValue("@a", emp_id);
            if (cmd.ExecuteNonQuery()>0)
            {
                con.Close();
                ViewData["employerDeleted"] = "        Employer is deleted successfully!";
            }
            con.Close();
            return View("adminDashboard");
        }
        public IActionResult deleteApplicant(string app_id)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from dbo.applicant_signup where app_email=@a", con);
            cmd.Parameters.AddWithValue("@a", app_id);
            if (cmd.ExecuteNonQuery() > 0)
            {
                con.Close();
                ViewData["applicantDeleted"] = "        Applicant is deleted successfully!";
            }
            con.Close();
            return View("adminDashboard");
        }
        public IActionResult cvPage()
        {
            return View("cvPage");
        }
        public IActionResult adminFeedbackSection()
        {
            return View();
        }
        public IActionResult adminProfileSection()
        {
            ViewData["adminName"] = adminName;
            ViewBag.adminNameViewBag = TempData["ADMIN_NAME_STORING"];
            TempData.Keep("ADMIN_NAME_STORING");
            return View();
        }
        public IActionResult editAdminProfile()
        {
            ViewBag.adminNameViewBag = TempData["ADMIN_NAME_STORING"];
            TempData.Keep("ADMIN_NAME_STORING");
            return View();
        }
        public IActionResult adminPostVerification()
        {
            return View();
        }
       
        public IActionResult feedback(string feedback_email,string feedback_message)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into feedback values(@a,@b)", con);
            cmd.Parameters.AddWithValue("@a", feedback_email);
            cmd.Parameters.AddWithValue("@b", feedback_message);
            if (cmd.ExecuteNonQuery() > 0)
            {
                ViewData["feedback"] = "Your feedback has submitted sucessfully!";
                con.Close();
                return View("contactUs");
            }
            return View("contactUs");
        }
        public IActionResult adminCheckLogin(string admin_name,string admin_password)
        {

            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select admin_email,admin_password from admintable where admin_email=@a and admin_password=@b", con);
            cmd.Parameters.AddWithValue("@a", admin_name);
            cmd.Parameters.AddWithValue("@b", admin_password);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            con.Close();
            DataTable table = dataSet.Tables[0];
            if (table.Rows.Count > 0)
            {
                con.Close();
                ViewData["adminName"] = admin_name;
                TempData["ADMIN_NAME_STORING"] = admin_name;
                adminName = admin_name;

                var sessionObject = new Class();
                sessionObject.adminName = admin_name;
                sessionObject.adminPassword = admin_password;

                HttpContext.Session.SetString("AdmnSession1", JsonConvert.SerializeObject(sessionObject));


                return View("adminDashboard");
            }
            return View("adminLogin");
        }
        public IActionResult editAdminProfileAction(string admin_first_name,string admin_last_name, string admin_contact,string admin_email,string admin_address, string admin_password)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update admintable set admin_first_name=@a,admin_last_name=@b,admin_contact=@c,admin_email=@d,admin_address=@e,admin_password=@f where admin_email=@g", con);
            cmd.Parameters.AddWithValue("@a", admin_first_name);
            cmd.Parameters.AddWithValue("@b", admin_last_name);
            cmd.Parameters.AddWithValue("@c", admin_contact);
            cmd.Parameters.AddWithValue("@d", admin_email); 
            cmd.Parameters.AddWithValue("@e", admin_address);
            cmd.Parameters.AddWithValue("@f", admin_password);
            cmd.Parameters.AddWithValue("@g", admin_email);
            if (cmd.ExecuteNonQuery() > 0)
            {
                ViewData["adminProfileEdited"] = "Your About is Updated Successfully!";
                ViewBag.adminNameViewBag = TempData["ADMIN_NAME_STORING"];
                TempData.Keep("ADMIN_NAME_STORING");
                con.Close();
            }
            return View("adminProfileSection");
        }
        [HttpPost]
        public IActionResult adminLogout()
        {
            HttpContext.Session.Clear();
            return Redirect("mainLoginPage");
        }


        //Employer
        public IActionResult employerSignUp()
        {
            return View();
        }
        public IActionResult loginEmployer()
        {

            return View();
        }
        public IActionResult EmployercheckLogin(string employer_username, string employer_password)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select emp_email,emp_password from employer_signup where emp_email=@username and emp_password=@password", con);
            cmd.Parameters.AddWithValue("@username", employer_username);
            cmd.Parameters.AddWithValue("@password", employer_password);

            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            con.Close();
            DataTable table = dataSet.Tables[0];
            if (table.Rows.Count > 0)
            {
                ViewData["employerName"] = employer_username;
                employerName = employer_username;
                TempData["EMP_NAME_STORING"] = employer_username;
                ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
                TempData.Keep();
                return View("Employerdashboard");
            }
            return View("loginEmployer");
        }

        public IActionResult insertEmployer(string emp_first_name, string emp_last_name, string emp_contact, string emp_email, string emp_password, string? emp_companies = null)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into employer_signup values(@a,@b,@c,@d,@e,@f)", con);
            cmd.Parameters.AddWithValue("@a", emp_first_name);
            cmd.Parameters.AddWithValue("@b", emp_last_name);
            cmd.Parameters.AddWithValue("@c", emp_contact);
            cmd.Parameters.AddWithValue("@d", emp_email);
            cmd.Parameters.AddWithValue("@e", emp_password);
            cmd.Parameters.AddWithValue("@f", emp_companies);
            if (cmd.ExecuteNonQuery() > 0)
            {
                return View("mainLoginPage");
            }
            con.Close();
            return View("signup");
        }
        public IActionResult Employerdashboard(string employer_username)
        {
            ViewData["username"] = employer_username;
            ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
            TempData.Keep("EMP_NAME_STORING");
            return View();
        }
        public IActionResult EmployerProfileSection()
        {
            ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
            TempData.Keep("EMP_NAME_STORING");
            return View();
        }
        public IActionResult EditEmployerProfile()
        {
            ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
            TempData.Keep("EMP_NAME_STORING");
            return View();
        }
        public IActionResult Employer_edit(string emp_first_name, string emp_last_name, string emp_contact, string emp_email, string emp_password,string emp_company)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update employer_signup set emp_first_name=@a,emp_last_name=@b,emp_contact=@c,emp_email=@d,emp_password=@f,emp_comapnies=@e where emp_email=@g", con);
            cmd.Parameters.AddWithValue("@a", emp_first_name);
            cmd.Parameters.AddWithValue("@b", emp_last_name);
            cmd.Parameters.AddWithValue("@c", emp_contact);
            cmd.Parameters.AddWithValue("@d", emp_email);
            cmd.Parameters.AddWithValue("@f", emp_password);
            cmd.Parameters.AddWithValue("@e", emp_company);
            cmd.Parameters.AddWithValue("@g", emp_email);
            if (cmd.ExecuteNonQuery() > 0)
            {
                ViewData["employerProfileEdited"] = "Your Profile is Updated Successfully!";
                ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
                TempData.Keep("EMP_NAME_STORING");
                con.Close();
            }
            return View("EmployerProfileSection");
        }
        public IActionResult deleteJob(string job_id)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from jobs where job_id=@a", con);
            cmd.Parameters.AddWithValue("@a", job_id);
            if (cmd.ExecuteNonQuery() > 0)
            {
                ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
                TempData.Keep("EMP_NAME_STORING");
                con.Close();

                ViewData["jobDeleted"] = "Job is deleted successfully!";
            }
            con.Close();
            return View("Employerdashboard");
        }
        public IActionResult Job_Updated(string job_id, string emp_email,string ptitle, string jtitle, string field, int salary, int agelimit, string city)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update jobs set project_title=@a,emp_email=@h,job_title=@b,field=@c,salary=@d,age_limit=@e,city=@f where job_id=@g and emp_email=@k", con);
            cmd.Parameters.AddWithValue("@a", ptitle);
            cmd.Parameters.AddWithValue("@h", emp_email);
            cmd.Parameters.AddWithValue("@b", jtitle);
            cmd.Parameters.AddWithValue("@c", field);
            cmd.Parameters.AddWithValue("@d", salary);
            cmd.Parameters.AddWithValue("@e", agelimit);
            cmd.Parameters.AddWithValue("@f", city);
            cmd.Parameters.AddWithValue("@g", job_id);
            cmd.Parameters.AddWithValue("@k", emp_email);
            if (cmd.ExecuteNonQuery() > 0)
            {
                ViewData["job updated"] = "Job is Updated Successfully!";
                con.Close();
                ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
                TempData.Keep("EMP_NAME_STORING");
                return View("Employerdashboard");
            }
            return View("Employerdashboard");
        }
        public IActionResult Job(string ptitle,string emp_email, string jtitle, string field, int salary, int agelimit, string city)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into jobs values(@a,@g,@b,@c,@d,@e,@f)", con);
            cmd.Parameters.AddWithValue("@a", ptitle);
            cmd.Parameters.AddWithValue("@g", emp_email);
            cmd.Parameters.AddWithValue("@b", jtitle);
            cmd.Parameters.AddWithValue("@c", field);
            cmd.Parameters.AddWithValue("@d", salary);
            cmd.Parameters.AddWithValue("@e", agelimit);
            cmd.Parameters.AddWithValue("@f", city);
            if (cmd.ExecuteNonQuery() > 0)
            {
                ViewData["feedback"] = "Job posted sucessfully!";
                con.Close();
                ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
                TempData.Keep("EMP_NAME_STORING");
                return View("Employerdashboard");
            }
            return View("postnewJob");
        }
        public IActionResult jobUpdate(string job_id)
            {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from jobs where job_id=@a", con);
            cmd.Parameters.AddWithValue("@a", job_id);
            SqlDataAdapter adapt = new SqlDataAdapter(cmd);
            DataSet data = new DataSet();
            adapt.Fill(data);
            DataTable table = data.Tables[0];
            ViewData["id"] = @table.Rows[0][0];
            ViewData["a"] = @table.Rows[0][1];
            ViewData["b"] = @table.Rows[0][2];
            ViewData["c"] = @table.Rows[0][3];
            ViewData["d"] = @table.Rows[0][4];
            ViewData["e"] = @table.Rows[0][5];
            ViewData["f"] = @table.Rows[0][6];
            ViewData["g"] = @table.Rows[0][7];
            con.Close();
            ViewBag.empNameViewBag = TempData["EMP_NAME_STORING"];
            TempData.Keep("EMP_NAME_STORING");
            return View();
            }
            
        public IActionResult postNewJob()
        {
            return View();
        }
        public IActionResult EmpLogout()
        {
            return Redirect("mainLoginPage");
        }



        //Applicant

        public IActionResult signUp()
        {

            return View();
        }
        public IActionResult loginApplicant()
        {
            return View();
        }
        public IActionResult applicantCheckLogin(string app_name,string app_password)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select app_email,app_password from applicant_signup where app_email=@username and app_password=@password", con);
            cmd.Parameters.AddWithValue("@username", app_name);
            cmd.Parameters.AddWithValue("@password", app_password);

            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataSet dataSet = new DataSet();
            dataAdapter.Fill(dataSet);
            con.Close();
            DataTable table = dataSet.Tables[0];
            if (table.Rows.Count > 0)
            {
                ViewData["employerName"] = app_name;
                employerName = app_name;
                TempData["APP_NAME_STORING"] = app_name;
                return View("applicantDashboard");
            }
            return View("loginApplicant");
        }
        public IActionResult insertApplicant(string app_first_name, string app_last_name, string app_contact, string app_email, string app_password)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into applicant_signup values(@a,@b,@c,@d,@e)", con);
            cmd.Parameters.AddWithValue("@a", app_first_name);
            cmd.Parameters.AddWithValue("@b", app_last_name);
            cmd.Parameters.AddWithValue("@c", app_contact);
            cmd.Parameters.AddWithValue("@d", app_email);
            cmd.Parameters.AddWithValue("@e", app_password);
            if (cmd.ExecuteNonQuery() > 0)
            {
                return View("mainLoginPage");
            }
            con.Close();
            return View("signup");
        }
        public IActionResult applicantDashboard()
        {

            return View();
        }
        public IActionResult applicantProfileSection()
        {
            ViewBag.appNameViewBag = TempData["APP_NAME_STORING"];
            TempData.Keep("APP_NAME_STORING");
            return View();
        }
        public IActionResult editApplicantProfile()
        {
            ViewBag.appNameViewBag = TempData["APP_NAME_STORING"];
            TempData.Keep("APP_NAME_STORING");
            return View();
        }
        public IActionResult ViewCV()
        {
            ViewBag.appNameViewBag = TempData["APP_NAME_STORING"];
            TempData.Keep("APP_NAME_STORING");
            return View();
        }
        public IActionResult EditCV()
        {
            ViewBag.appNameViewBag = TempData["APP_NAME_STORING"];
            TempData.Keep("APP_NAME_STORING");
            return View();
        }
        public IActionResult editapplicantProfileAction(string app_first_name, string app_last_name,string app_contact,string app_email,string app_password)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update applicant_signup set app_first_name=@a,app_last_name=@b,app_contact=@c,app_email=@d,app_password=@f where app_email=@g", con);
            cmd.Parameters.AddWithValue("@a", app_first_name);
            cmd.Parameters.AddWithValue("@b", app_last_name);
            cmd.Parameters.AddWithValue("@c", app_contact);
            cmd.Parameters.AddWithValue("@d", app_email);
            cmd.Parameters.AddWithValue("@f", app_password);
            cmd.Parameters.AddWithValue("@g", app_email);
            if (cmd.ExecuteNonQuery() > 0)
            {
                ViewData["appProfileEdited"] = "Your About is Updated Successfully!";
                ViewBag.appNameViewBag = TempData["APP_NAME_STORING"];
                TempData.Keep("APP_NAME_STORING");
                con.Close();
            }
            return View("applicantProfileSection");
        }
        public IActionResult CVForm(string FirstName, string LastName, string Email, string Gender, string Qualification, string titleOfLastDegree, string Experience, string Skills, string Interests, string Age, string cellPhone, string City, string Address)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into applicant_cv values(@a,@b,@c,@d,@e,@f,@g,@h,@i,@j,@k,@l,@m)", con);
            cmd.Parameters.AddWithValue("@a", FirstName);
            cmd.Parameters.AddWithValue("@b", LastName);
            cmd.Parameters.AddWithValue("@c", Email);
            cmd.Parameters.AddWithValue("@d", Gender);
            cmd.Parameters.AddWithValue("@e", Qualification);
            cmd.Parameters.AddWithValue("@f", titleOfLastDegree);
            cmd.Parameters.AddWithValue("@g", Experience);
            cmd.Parameters.AddWithValue("@h", Skills);
            cmd.Parameters.AddWithValue("@i", Interests);
            cmd.Parameters.AddWithValue("@j", Age);
            cmd.Parameters.AddWithValue("@k", cellPhone);
            cmd.Parameters.AddWithValue("@l", City);
            cmd.Parameters.AddWithValue("@m", Address);

            if (cmd.ExecuteNonQuery() > 0)
            {
                return View("loginApplicant");
            }
            con.Close();
            return View("cvPage");
        }


        public IActionResult UpdateCV(string FirstName, string LastName, string Email, string Gender, string Qualification, string titleOfLastDegree, string Experience, string Skills, string Interests, string Age, string cellPhone, string City, string Address)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-4F3BL6V\\AYESHAAZAM;Initial Catalog=OnlineJobPortal;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update applicant_cv set first_ame=@a,last_name=@b,app_email=@c,gender=@d,qualification=@e,title_of_last_degree=@f,experince=@g,skills=@h,interest=@i,age=@j,cell_phone=@k,city=@l,adres=@m where app_email=@n", con);
            cmd.Parameters.AddWithValue("@a", FirstName);
            cmd.Parameters.AddWithValue("@b", LastName);
            cmd.Parameters.AddWithValue("@c", Email);
            cmd.Parameters.AddWithValue("@d", Gender);
            cmd.Parameters.AddWithValue("@e", Qualification);
            cmd.Parameters.AddWithValue("@f", titleOfLastDegree);
            cmd.Parameters.AddWithValue("@g", Experience);
            cmd.Parameters.AddWithValue("@h", Skills);
            cmd.Parameters.AddWithValue("@i", Interests);
            cmd.Parameters.AddWithValue("@j", Age);
            cmd.Parameters.AddWithValue("@k", cellPhone);
            cmd.Parameters.AddWithValue("@l", City);
            cmd.Parameters.AddWithValue("@m", Address);
            cmd.Parameters.AddWithValue("@n", Email);

            if (cmd.ExecuteNonQuery() > 0)
            {
                ViewBag.appNameViewBag = TempData["APP_NAME_STORING"];
                TempData.Keep("APP_NAME_STORING");
                return View("ViewCV");
            }
            con.Close();
            return View("EditCV");
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
