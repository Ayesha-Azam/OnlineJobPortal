﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace OnlineJobPortal.Models
{
    public class loginEmployerClass
    {
        [Required(ErrorMessage ="Enter Your Username.")]
        public string employer_username { get; set; }
        public string employer_password { get; set; }
    }
}
