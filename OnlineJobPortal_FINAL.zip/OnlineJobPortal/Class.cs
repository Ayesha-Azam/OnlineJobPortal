﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineJobPortal.Controllers
{
    public class Class
    {
       public string adminName { get; set; }
       public string adminPassword { get; set; }


    }
}
